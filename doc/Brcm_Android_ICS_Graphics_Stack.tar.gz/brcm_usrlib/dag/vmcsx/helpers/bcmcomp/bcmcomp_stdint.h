#ifndef BCMCOMP_STDINT_H
#define BCMCOMP_STDINT_H

#include "vcinclude/common.h"

#endif // BCMCOMP_STDINT_H
