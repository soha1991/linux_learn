
// just to test we can compile under C++

#include "interface/vcos/vcos.h"

class foo {};

extern "C" void a_cpp_function(void) {}

