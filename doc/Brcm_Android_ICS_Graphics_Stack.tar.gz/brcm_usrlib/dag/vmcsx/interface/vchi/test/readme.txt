README.TXT
==========


This folder contains test code for the VCHI layer, intended to be used on a host

comms_test     Starts up the VCHI comms stack and runs a 'version' gencmd, displaying the result
               Number of runs specified on command line


mphi_test      A lower level test program requiring a custom app on the VC03 (mphi_comms). 
               This probably won't work in most cases - left in for reference