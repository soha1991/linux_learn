README.TXT
==========

This folder contains the linux driver for 2820/2727B0 DK

Contents should be copied to the linux build tree where a kernel 
build will include it in to the kernel.

mpg-app\build-output\linux-2.6.23.17\drivers\char\broadcom\vc03b0